
public class Contador extends Funcionario {

	@Override
	public double getBonificacion() {
		return 200;
	}
}
